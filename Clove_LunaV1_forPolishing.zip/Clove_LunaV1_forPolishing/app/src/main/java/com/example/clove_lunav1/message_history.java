package com.example.clove_lunav1;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.clove_lunav1.databse.CloveDatabase;
import com.example.clove_lunav1.databse.MessageHistory;
import com.example.clove_lunav1.databse.MessageHistoryDao;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class message_history extends AppCompatActivity {

    // Container where the message history cards are displayed.
    private LinearLayout historyContainer;

    // DAO provides access to saved message history in Room.
    private MessageHistoryDao messageHistoryDao;

    // Run database operations in the background.
    private final ExecutorService databaseExecutor =
            Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Enable edge-to-edge screen display.
        EdgeToEdge.enable(this);

        // Load the existing message history layout.
        setContentView(R.layout.activity_message_history);

        // Adjust padding so content does not overlap system bars.
        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main),
                (v, insets) -> {

                    Insets systemBars = insets.getInsets(
                            WindowInsetsCompat.Type.systemBars()
                    );

                    v.setPadding(
                            systemBars.left,
                            systemBars.top,
                            systemBars.right,
                            systemBars.bottom
                    );

                    return insets;
                }
        );

        // Connect to the existing Room database.
        messageHistoryDao = CloveDatabase
                .getInstance(getApplicationContext())
                .messageHistoryDao();

        // Find the container used for displaying history cards.
        historyContainer = findViewById(R.id.historyContainer);

        // Load saved history from the database.
        displayHistory();
    }

    private void displayHistory() {

        // Retrieve saved history in the background.
        databaseExecutor.execute(() -> {

            List<MessageHistory> savedMessages =
                    messageHistoryDao.getAll();

            // Update the screen on the main UI thread.
            runOnUiThread(() -> {

                // Stop if this screen is already closing.
                if (isFinishing() || isDestroyed()) {
                    return;
                }

                // Clear old cards before displaying the latest results.
                historyContainer.removeAllViews();

                // The DAO returns messages newest first.
                for (MessageHistory history : savedMessages) {

                    // Create a card using your existing XML layout.
                    View card = getLayoutInflater().inflate(
                            R.layout.item_message_history,
                            historyContainer,
                            false
                    );

                    // Find the message and time labels inside the card.
                    TextView txtMessage =
                            card.findViewById(R.id.txtHistoryMessage);

                    TextView txtTime =
                            card.findViewById(R.id.txtHistoryTime);

                    // Display the saved message text.
                    txtMessage.setText(history.messageText);

                    // Convert the saved timestamp into a readable time.
                    SimpleDateFormat sdf = new SimpleDateFormat(
                            "hh:mm a",
                            Locale.getDefault()
                    );

                    txtTime.setText(
                            sdf.format(new Date(history.timestamp))
                    );

                    // Add the completed card to the history screen.
                    historyContainer.addView(card);
                }
            });
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        // Shut down the background executor when the screen closes.
        databaseExecutor.shutdown();
    }
}