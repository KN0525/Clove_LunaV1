package com.example.clove_lunav1.databse;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface CustomMessageDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void save(CustomMessage message);

    @Query("SELECT * FROM custom_messages ORDER BY code")
    List<CustomMessage> getAll();

    @Query("SELECT * FROM custom_messages WHERE code = :code LIMIT 1")
    CustomMessage getByCode(String code);
}
