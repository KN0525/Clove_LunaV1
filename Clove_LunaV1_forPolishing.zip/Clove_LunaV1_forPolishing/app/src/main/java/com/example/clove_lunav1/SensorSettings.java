
package com.example.clove_lunav1;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.clove_lunav1.databse.CloveDatabase;
import com.example.clove_lunav1.databse.SensorCalibration;
import com.example.clove_lunav1.databse.SensorCalibrationDao;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SensorSettings extends AppCompatActivity {

    private TextView txtThumbReading;
    private TextView txtIndexReading;
    private TextView txtMiddleReading;
    private TextView txtRingReading;
    private TextView txtPinkyReading;

    private EditText editThumbOpen;
    private EditText editIndexOpen;
    private EditText editMiddleOpen;
    private EditText editRingOpen;
    private EditText editPinkyOpen;

    private Button btnSaveCalibration;
    private Button btnRecalibrate;

    private final ExecutorService databaseExecutor =
            Executors.newSingleThreadExecutor();

    private final Handler sensorHandler =
            new Handler(Looper.getMainLooper());

    private final Runnable updateSensorReadings = new Runnable() {
        @Override
        public void run() {
            displayLatestReadings();
            sensorHandler.postDelayed(this, 250);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sensor_settings);

        View mainView = findViewById(R.id.main);

        ViewCompat.setOnApplyWindowInsetsListener(
                mainView,
                (v, insets) -> {
                    Insets systemBars = insets.getInsets(
                            WindowInsetsCompat.Type.systemBars()
                    );

                    v.setPadding(
                            systemBars.left,
                            systemBars.top,
                            systemBars.right,
                            systemBars.bottom
                    );

                    return insets;
                }
        );

        // Live sensor reading displays
        txtThumbReading = findViewById(R.id.txtThumbReading);
        txtIndexReading = findViewById(R.id.txtIndexReading);
        txtMiddleReading = findViewById(R.id.txtMiddleReading);
        txtRingReading = findViewById(R.id.txtRingReading);
        txtPinkyReading = findViewById(R.id.txtPinkyReading);

        // Calibration input fields
        editThumbOpen = findViewById(R.id.editThumbOpen);
        editIndexOpen = findViewById(R.id.editIndexOpen);
        editMiddleOpen = findViewById(R.id.editMiddleOpen);
        editRingOpen = findViewById(R.id.editRingOpen);
        editPinkyOpen = findViewById(R.id.editPinkyOpen);

        // Buttons
        btnSaveCalibration = findViewById(R.id.btnSaveCalibration);
        btnRecalibrate = findViewById(R.id.btnRecalibrate);

        // Load previously saved calibration values.
        loadSavedCalibration();

        // Save the five calibration values.
        btnSaveCalibration.setOnClickListener(v -> saveCalibration());

        // Resume live sensor readings.
        btnRecalibrate.setOnClickListener(v -> {
            resumeSensorReadings();

            Toast.makeText(
                    SensorSettings.this,
                    "Live sensor readings resumed",
                    Toast.LENGTH_SHORT
            ).show();
        });
    }

    private void saveCalibration() {

        EditText[] fields = {
                editThumbOpen,
                editIndexOpen,
                editMiddleOpen,
                editRingOpen,
                editPinkyOpen
        };

        String[] sensorNames = {
                "Thumb",
                "Index",
                "Middle",
                "Ring",
                "Pinky"
        };

        int[] openValues = new int[5];

        // Validate all five fields before saving anything.
        for (int i = 0; i < fields.length; i++) {

            String input = fields[i].getText()
                    .toString()
                    .trim();

            if (input.isEmpty()) {
                fields[i].setError("Enter this sensor's open value");
                fields[i].requestFocus();
                return;
            }

            try {
                int value = Integer.parseInt(input);

                if (value < 0 || value > 4095) {
                    fields[i].setError(
                            "Enter a value from 0 to 4095"
                    );
                    fields[i].requestFocus();
                    return;
                }

                openValues[i] = value;

            } catch (NumberFormatException e) {
                fields[i].setError("Enter a valid whole number");
                fields[i].requestFocus();
                return;
            }
        }

        btnSaveCalibration.setEnabled(false);

        SensorCalibrationDao dao =
                CloveDatabase.getInstance(getApplicationContext())
                        .sensorCalibrationDao();

        databaseExecutor.execute(() -> {
            try {
                // Save each finger's calibration record.
                for (int i = 0; i < sensorNames.length; i++) {

                    SensorCalibration calibration =
                            new SensorCalibration(sensorNames[i]);

                    calibration.openValue = (float) openValues[i];
                    calibration.isCalibrated = true;

                    dao.save(calibration);
                }

                runOnUiThread(() -> {
                    btnSaveCalibration.setEnabled(true);

                    // Pause raw sensor transmissions after saving.
                    MainActivity.sendCommandFromSettings("RAW_OFF");
                    sensorHandler.removeCallbacks(
                            updateSensorReadings
                    );

                    Toast.makeText(
                            SensorSettings.this,
                            "Calibration saved successfully!",
                            Toast.LENGTH_SHORT
                    ).show();
                });

            } catch (Exception e) {
                Log.e(
                        "CLOVE_DATABASE",
                        "Could not save calibration",
                        e
                );

                runOnUiThread(() -> {
                    btnSaveCalibration.setEnabled(true);

                    Toast.makeText(
                            SensorSettings.this,
                            "Database save failed. Check Logcat.",
                            Toast.LENGTH_LONG
                    ).show();
                });
            }
        });
    }

    private void loadSavedCalibration() {

        SensorCalibrationDao dao =
                CloveDatabase.getInstance(getApplicationContext())
                        .sensorCalibrationDao();

        databaseExecutor.execute(() -> {
            try {
                String[] sensorNames = {
                        "Thumb",
                        "Index",
                        "Middle",
                        "Ring",
                        "Pinky"
                };

                EditText[] fields = {
                        editThumbOpen,
                        editIndexOpen,
                        editMiddleOpen,
                        editRingOpen,
                        editPinkyOpen
                };

                for (int i = 0; i < sensorNames.length; i++) {
                    SensorCalibration saved =
                            dao.getByName(sensorNames[i]);

                    if (saved != null) {
                        final int index = i;
                        final String value =
                                String.valueOf(saved.openValue);

                        runOnUiThread(() ->
                                fields[index].setText(value)
                        );
                    }
                }

            } catch (Exception e) {
                Log.e(
                        "CLOVE_DATABASE",
                        "Could not load calibration",
                        e
                );

                runOnUiThread(() ->
                        Toast.makeText(
                                SensorSettings.this,
                                "Could not load saved calibration",
                                Toast.LENGTH_SHORT
                        ).show()
                );
            }
        });
    }

    private void resumeSensorReadings() {

        MainActivity.sendCommandFromSettings("RAW_ON");

        sensorHandler.removeCallbacks(updateSensorReadings);
        sensorHandler.post(updateSensorReadings);
    }

    @Override
    protected void onResume() {
        super.onResume();

        sensorHandler.removeCallbacks(updateSensorReadings);
        sensorHandler.post(updateSensorReadings);
    }

    @Override
    protected void onPause() {
        super.onPause();

        sensorHandler.removeCallbacks(updateSensorReadings);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        sensorHandler.removeCallbacks(updateSensorReadings);

        // Do not shut down the executor while database work is pending.
        // The executor is retained for the lifetime of this Activity.
    }

    private void displayLatestReadings() {

        if (!MainActivity.hasSensorReadings) {
            return;
        }

        int[] readings = MainActivity.latestSensorReadings;

        if (readings == null || readings.length < 5) {
            return;
        }

        txtThumbReading.setText(String.valueOf(readings[0]));
        txtIndexReading.setText(String.valueOf(readings[1]));
        txtMiddleReading.setText(String.valueOf(readings[2]));
        txtRingReading.setText(String.valueOf(readings[3]));
        txtPinkyReading.setText(String.valueOf(readings[4]));
    }
}
