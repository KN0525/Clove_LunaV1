
package com.example.clove_lunav1;

import android.os.Bundle;
import android.graphics.Color;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.clove_lunav1.databse.CloveDatabase;
import com.example.clove_lunav1.databse.CustomMessage;
import com.example.clove_lunav1.databse.CustomMessageDao;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Customize extends AppCompatActivity {

    private TextView[] messageViews;
    private Button[] editButtons;

    private CustomMessageDao customMessageDao;

    private final ExecutorService databaseExecutor =
            Executors.newSingleThreadExecutor();

    // Fixed emergency message that cannot be customized.
    private static final String EMERGENCY_CODE = "1";
    private static final String EMERGENCY_MESSAGE =
            "EMERGENCY! I NEED IMMEDIATE HELP!";

    private final String[] defaultMessages = {
            "EMERGENCY! I NEED IMMEDIATE HELP!",
            "I'm Hungry",
            "I need water",
            "I need help",
            "Toilet",
            "yes",
            "no",
            "Ok",
            "I Love You",
            "Thank You",
            "I want to Sleep",
            "Not set"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_customize);

        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main),
                (v, insets) -> {
                    Insets systemBars = insets.getInsets(
                            WindowInsetsCompat.Type.systemBars()
                    );

                    v.setPadding(
                            systemBars.left,
                            systemBars.top,
                            systemBars.right,
                            systemBars.bottom
                    );

                    return insets;
                }
        );


        // Connect to the existing Room database.
        customMessageDao = CloveDatabase
                .getInstance(getApplicationContext())
                .customMessageDao();

        messageViews = new TextView[]{
                findViewById(R.id.messageText1),
                findViewById(R.id.messageText2),
                findViewById(R.id.messageText3),
                findViewById(R.id.messageText4),
                findViewById(R.id.messageText5),
                findViewById(R.id.messageText6),
                findViewById(R.id.messageText7),
                findViewById(R.id.messageText8),
                findViewById(R.id.messageText9),
                findViewById(R.id.messageText10),
                findViewById(R.id.messageText11),
                findViewById(R.id.messageText12)
        };

        editButtons = new Button[]{
                findViewById(R.id.btnEditMessage2),
                findViewById(R.id.btnEditMessage3),
                findViewById(R.id.btnEditMessage4),
                findViewById(R.id.btnEditMessage5),
                findViewById(R.id.btnEditMessage6),
                findViewById(R.id.btnEditMessage7),
                findViewById(R.id.btnEditMessage8),
                findViewById(R.id.btnEditMessage9),
                findViewById(R.id.btnEditMessage10),
                findViewById(R.id.btnEditMessage11),
                findViewById(R.id.btnEditMessage12)
        };

        //button start at 2 so the algo will read from 2 - 12
        for (int i = 0; i < editButtons.length; i++) {
            final int position = i + 1;

            editButtons[i].setOnClickListener(
                    v -> showEditDialog(position)
            );
        }

        loadMessages();
    }

    private void loadMessages() {
        databaseExecutor.execute(() -> {
            List<CustomMessage> savedMessages =
                    customMessageDao.getAll();
            // Skip Gesture 1 because it is the fixed emergency message.
            for (CustomMessage saved : savedMessages) {
                try {
                    int position = Integer.parseInt(saved.code) - 1;

                    // Skip position 0 (Gesture 1).
                    // Only Gestures 2–12 can load customized messages.
                    if (position >= 1 && position < messageViews.length) {
                        messageViews[position].setText(
                                saved.messageText == null
                                        ? defaultMessages[position]
                                        : saved.messageText
                        );
                    }

                } catch (NumberFormatException ignored) {
                    // Ignore codes that are not numeric.
                }
            }

            // Always display the fixed emergency message for Gesture 1.
            messageViews[0].setText("EMERGENCY! I NEED IMMEDIATE HELP!");

            // Restore the fixed emergency message after loading.
            messageViews[0].setText(EMERGENCY_MESSAGE);
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) {
                    return;
                }

                // Start with the default messages.
                for (int i = 0; i < messageViews.length; i++) {
                    messageViews[i].setText(defaultMessages[i]);
                }

                // Replace defaults with saved database messages.
                for (CustomMessage saved : savedMessages) {
                    try {
                        int position =
                                Integer.parseInt(saved.code) - 1;

                        if (position >= 0
                                && position < messageViews.length) {

                            messageViews[position].setText(
                                    saved.messageText == null
                                            ? defaultMessages[position]
                                            : saved.messageText
                            );
                        }
                    } catch (NumberFormatException ignored) {
                        // Ignore codes that are not numeric.
                    }
                }
            });
        });
    }

    private void showEditDialog(int position) {
        EditText input = new EditText(this);

        input.setHint("Enter your message");
        input.setTextSize(16);
        input.setTextColor(Color.BLACK);
        input.setHintTextColor(Color.GRAY);
        input.setMinLines(2);
        input.setMaxLines(4);
        input.setGravity(
                android.view.Gravity.TOP
                        | android.view.Gravity.START
        );
        input.setPadding(32, 24, 32, 24);

        String currentMessage =
                messageViews[position].getText().toString();

        if (!currentMessage.equals("Not set")) {
            input.setText(currentMessage);
            input.setSelection(input.getText().length());
        }

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Edit Gesture " + (position + 1))
                .setMessage("Enter the message for this gesture.")
                .setView(input)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", (d, which) -> d.dismiss())
                .create();

        dialog.setOnShowListener(d -> {
            Window window = dialog.getWindow();

            if (window != null) {
                window.setSoftInputMode(
                        android.view.WindowManager.LayoutParams
                                .SOFT_INPUT_STATE_ALWAYS_HIDDEN
                );
            }

            Button saveButton = dialog.getButton(
                    AlertDialog.BUTTON_POSITIVE
            );

            saveButton.setOnClickListener(v -> {
                String newMessage = input.getText()
                        .toString()
                        .trim();

                if (newMessage.isEmpty()) {
                    input.setError("Please enter a message");
                    return;
                }

                String code = String.valueOf(position + 1);
                String label = "Gesture " + (position + 1);

                CustomMessage customMessage = new CustomMessage(
                        code,
                        label,
                        newMessage,
                        true
                );

                saveButton.setEnabled(false);

                // Save on a background thread.
                databaseExecutor.execute(() -> {
                    try {
                        customMessageDao.save(customMessage);

                        runOnUiThread(() -> {
                            if (isFinishing() || isDestroyed()) {
                                return;
                            }

                            // Update the selected card only.
                            messageViews[position].setText(newMessage);

                            Toast.makeText(
                                    Customize.this,
                                    label + " message saved",
                                    Toast.LENGTH_SHORT
                            ).show();

                            dialog.dismiss();
                        });

                    } catch (Exception e) {
                        runOnUiThread(() -> {
                            if (isFinishing() || isDestroyed()) {
                                return;
                            }

                            saveButton.setEnabled(true);

                            Toast.makeText(
                                    Customize.this,
                                    "Unable to save message. Please try again.",
                                    Toast.LENGTH_LONG
                            ).show();
                        });
                    }
                });
            });
        });

        dialog.show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        databaseExecutor.shutdown();
    }
}
