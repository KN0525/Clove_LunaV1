package com.example.clove_lunav1.databse;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;
@Dao
public interface SensorCalibrationDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void save(SensorCalibration sensor);

    @Query("SELECT * FROM sensor_calibration")
    List<SensorCalibration> getAll();

    @Query("SELECT * FROM sensor_calibration WHERE sensorName = :name LIMIT 1")
    SensorCalibration getByName(String name);

}
