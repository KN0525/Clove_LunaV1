package com.example.clove_lunav1.databse;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "custom_messages")

public class CustomMessage {
    @PrimaryKey
    @NonNull
    public String code;

    public String label;
    public String messageText;
    public boolean enabled;

    public CustomMessage(
            @NonNull String code,
            String label,
            String messageText,
            boolean enabled) {
        this.code = code;
        this.label = label;
        this.messageText = messageText;
        this.enabled = enabled;
    }
}
