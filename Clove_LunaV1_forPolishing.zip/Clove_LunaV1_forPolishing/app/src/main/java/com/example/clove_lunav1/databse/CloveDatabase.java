package com.example.clove_lunav1.databse;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database(
        entities = {
                SensorCalibration.class,
                CustomMessage.class,
                MessageHistory.class
        },
        version = 2,
        exportSchema = false
)
public abstract class CloveDatabase extends RoomDatabase {

    private static volatile CloveDatabase INSTANCE;

    static final Migration MIGRATION_1_2 = new Migration(1, 2) {
        @Override
        public void migrate(SupportSQLiteDatabase db) {

            db.execSQL(
                    "CREATE TABLE sensor_calibration_new (" +
                            "sensorName TEXT NOT NULL, " +
                            "openValue REAL NOT NULL, " +
                            "isCalibrated INTEGER NOT NULL, " +
                            "PRIMARY KEY(sensorName))"
            );

            db.execSQL(
                    "INSERT INTO sensor_calibration_new " +
                            "(sensorName, openValue, isCalibrated) " +
                            "SELECT sensorName, openReading, isCalibrated " +
                            "FROM sensor_calibration"
            );

            db.execSQL("DROP TABLE sensor_calibration");

            db.execSQL(
                    "ALTER TABLE sensor_calibration_new " +
                            "RENAME TO sensor_calibration"
            );
        }
    };

    public abstract SensorCalibrationDao sensorCalibrationDao();

    public abstract CustomMessageDao customMessageDao();

    public abstract MessageHistoryDao messageHistoryDao();

    public static CloveDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (CloveDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                                    context.getApplicationContext(),
                                    CloveDatabase.class,
                                    "clove_database"
                            )
                            .addMigrations(MIGRATION_1_2)
                            .build();
                }
            }
        }

        return INSTANCE;
    }
}