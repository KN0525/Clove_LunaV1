package com.example.clove_lunav1.databse;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "message_history")

public class MessageHistory {
    @PrimaryKey(autoGenerate = true)
    public int id;

    public String code;
    public String messageText;
    public long timestamp;

    public MessageHistory(
            String code,
            String messageText,
            long timestamp) {
        this.code = code;
        this.messageText = messageText;
        this.timestamp = timestamp;
    }
}
