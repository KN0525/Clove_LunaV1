package com.example.clove_lunav1.databse;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;
@Dao
public interface MessageHistoryDao {
    @Insert
    void insert(MessageHistory message);

    @Query("SELECT * FROM message_history ORDER BY timestamp DESC")
    List<MessageHistory> getAll();

    @Query("DELETE FROM message_history")
    void clearAll();
}
