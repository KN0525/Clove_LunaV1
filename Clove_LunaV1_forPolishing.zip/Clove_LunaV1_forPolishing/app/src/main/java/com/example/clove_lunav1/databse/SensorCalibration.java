package com.example.clove_lunav1.databse;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "sensor_calibration")
public class SensorCalibration {

    @PrimaryKey
    @NonNull
    public String sensorName;

    // Sensor reading captured when the finger is open
    public float openValue;

    // True after the Open Value has been saved
    public boolean isCalibrated;

    public SensorCalibration(@NonNull String sensorName) {
        this.sensorName = sensorName;
        this.openValue = 0f;
        this.isCalibrated = false;
    }
}
