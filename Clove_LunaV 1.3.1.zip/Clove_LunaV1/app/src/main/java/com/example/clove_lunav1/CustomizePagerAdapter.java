package com.example.clove_lunav1;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class CustomizePagerAdapter
        extends RecyclerView.Adapter<CustomizePagerAdapter.PageViewHolder> {

    private final int[] pages = {
            R.layout.page_sensor_calibration,
            R.layout.page_message_settings
    };

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    @NonNull
    @Override
    public PageViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent,
            int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(
                        pages[viewType],
                        parent,
                        false
                );

        return new PageViewHolder(view);
    }

    @Override
    public void onBindViewHolder(
            @NonNull PageViewHolder holder,
            int position) {
    }

    @Override
    public int getItemCount() {
        return pages.length;
    }

    static class PageViewHolder
            extends RecyclerView.ViewHolder {

        PageViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}