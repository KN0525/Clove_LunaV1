package com.example.clove_lunav1;

import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.viewpager2.widget.ViewPager2;

public class Customize extends AppCompatActivity {

    ViewPager2 customizePager;

    View dotSensor;
    View dotMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);

        setContentView(R.layout.activity_customize);

        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main),
                (v, insets) -> {

                    Insets systemBars =
                            insets.getInsets(
                                    WindowInsetsCompat.Type.systemBars()
                            );

                    v.setPadding(
                            systemBars.left,
                            systemBars.top,
                            systemBars.right,
                            systemBars.bottom
                    );

                    return insets;
                }
        );

        // ViewPager
        customizePager =
                findViewById(R.id.customizePager);

        // Page indicator dots
        dotSensor =
                findViewById(R.id.dotSensor);

        dotMessage =
                findViewById(R.id.dotMessage);

        // Connect the pages
        CustomizePagerAdapter adapter =
                new CustomizePagerAdapter();

        customizePager.setAdapter(adapter);

        // Detect page changes
        customizePager.registerOnPageChangeCallback(
                new ViewPager2.OnPageChangeCallback() {

                    @Override
                    public void onPageSelected(int position) {
                        super.onPageSelected(position);

                        if (position == 0) {

                            // Sensor page
                            dotSensor.setBackgroundResource(
                                    R.drawable.bg_status_circle
                            );

                            dotMessage.setBackgroundResource(
                                    R.drawable.bg_action_card
                            );

                        } else {

                            // Message page
                            dotSensor.setBackgroundResource(
                                    R.drawable.bg_action_card
                            );

                            dotMessage.setBackgroundResource(
                                    R.drawable.bg_status_circle
                            );
                        }
                    }
                }
        );
    }
}