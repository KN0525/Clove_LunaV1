package com.example.clove_lunav1;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import androidx.core.app.NotificationCompat;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    // =========================================================
    // BLUETOOTH PERMISSIONS
    // =========================================================

    private static final int REQUEST_BLUETOOTH_PERMISSIONS = 100;


    // =========================================================
    // CLOVE BLE UUIDs
    // =========================================================

    private static final UUID SERVICE_UUID =
            UUID.fromString(
                    "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
            );

    private static final UUID CHARACTERISTIC_UUID =
            UUID.fromString(
                    "beb5483e-36e1-4688-b7f5-ea07361b26a8"
            );

    private static final UUID CLIENT_CHARACTERISTIC_CONFIG_UUID =
            UUID.fromString(
                    "00002902-0000-1000-8000-00805f9b34fb"
            );


    // =========================================================
    // MESSAGE HISTORY
    // =========================================================

    public static ArrayList<String> messageHistory =
            new ArrayList<>();


    // =========================================================
    // GUI
    // =========================================================

    TextView txtDetectionStatus;

    LinearLayout btnMessageHistory;

    LinearLayout btnCustomMessages;

    Button btnTestMessage;


    // =========================================================
    // BLUETOOTH
    // =========================================================

    BluetoothAdapter bluetoothAdapter;

    BluetoothLeScanner bluetoothScanner;

    BluetoothDevice cloveDevice;

    BluetoothGatt bluetoothGatt;

    Handler handler = new Handler();

    TextView txtConnectionStatus;
    Button btnConnection;
    View connectionIndicator;


    // =========================================================
    // ON CREATE
    // =========================================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);

        setContentView(R.layout.activity_main);
        //notification
        createNotificationChannel();
        //notification permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {

            if (ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(
                        this,
                        new String[]{
                                Manifest.permission.POST_NOTIFICATIONS
                        },
                        200
                );
            }
        }


        // =====================================================
        // WINDOW INSETS
        // =====================================================

        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main),
                (v, insets) -> {

                    Insets systemBars =
                            insets.getInsets(
                                    WindowInsetsCompat.Type.systemBars()
                            );

                    v.setPadding(
                            systemBars.left,
                            systemBars.top,
                            systemBars.right,
                            systemBars.bottom
                    );

                    return insets;
                }
        );


        // =====================================================
        // GUI
        // =====================================================

        txtDetectionStatus =
                findViewById(R.id.txtDetectionStatus);

        btnMessageHistory =
                findViewById(R.id.btnMessageHistory);

       // btnTestMessage = findViewById(R.id.btnTestMessage);

        // =====================================================
        // BLE connection status
        // =====================================================
        txtConnectionStatus = findViewById(R.id.txtConnectionStatus);
        btnConnection = findViewById(R.id.btnConnection);
        connectionIndicator = findViewById(R.id.connectionIndicator);




        // =====================================================
        // INITIAL STATUS
        // =====================================================

        txtDetectionStatus.setText(
                "Ready to detect\nmuscle movement"
        );


        // =====================================================
        // MESSAGE HISTORY BUTTON
        // =====================================================

        btnMessageHistory.setOnClickListener(view -> {

            android.content.Intent pass =
                    new android.content.Intent(
                            MainActivity.this,
                            message_history.class
                    );

            startActivity(pass);
        });

        // =====================================================
        // Customize BUTTON
        // =====================================================
        btnCustomMessages = findViewById(R.id.btnCustomMessages);
        btnCustomMessages.setOnClickListener(view -> {

            android.content.Intent pass =
                    new android.content.Intent(
                            MainActivity.this,
                            Customize.class
                    );

            startActivity(pass);
        });


        // =====================================================
        // TEST MESSAGE
        // =====================================================
        // We can remove this later after BLE is confirmed working.
        /*
        btnTestMessage.setOnClickListener(view -> {

            receiveMessage("YES");

        });
        */

        // =====================================================
        // BLUETOOTH SETUP
        // =====================================================

        BluetoothManager bluetoothManager =
                (BluetoothManager)
                        getSystemService(
                                Context.BLUETOOTH_SERVICE
                        );

        bluetoothAdapter =
                bluetoothManager.getAdapter();


        btnConnection.setOnClickListener(view -> {

            // Already connected
            if (bluetoothGatt != null) {

                disconnectFromClove();
                btnConnection.setText("Scan and Connect");


            }

            // CLOVE was found, but not connected yet
            else if (cloveDevice != null) {

                connectToClove();
                btnConnection.setText("Disconnect");
            }

            // Nothing found yet
            else {

                scanForClove();


            }

        });
    }

    private void createNotificationChannel() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            NotificationChannel channel =
                    new NotificationChannel(
                            "CLOVE_MESSAGES",
                            "CLOVE Messages",
                            NotificationManager.IMPORTANCE_HIGH
                    );

            channel.setDescription(
                    "Notifications received from the CLOVE glove"
            );

            // Enable vibration
            channel.enableVibration(true);

            // Vibration pattern:
            // wait 0ms → vibrate 300ms → pause 150ms → vibrate 300ms
            long[] vibrationPattern = {
                    0,
                    300,
                    150,
                    300
            };

            channel.setVibrationPattern(vibrationPattern);

            NotificationManager notificationManager =
                    getSystemService(NotificationManager.class);

            notificationManager.createNotificationChannel(channel);
        }
    }

    // =========================================================
    // RECEIVE MESSAGE
    // =========================================================

    private void receiveMessage(String rawMessage) {

        String message;


        // =====================================================
        // TRANSLATE ESP32 MESSAGE
        // =====================================================

        switch (rawMessage.trim()) {

            case "YES":

                message = "Shet Shet nakita ako";

                break;


            case "WATER":

                message = "I need water";

                break;


            case "HELP":

                message = "I need help";

                break;


            default:

                message = rawMessage;

                break;
        }


        // =====================================================
        // UPDATE HOME SCREEN
        // =====================================================

        txtDetectionStatus.setText(message);


        // =====================================================
        // SAVE MESSAGE + TIME
        // =====================================================

        messageHistory.add(
                message + "|" +
                        System.currentTimeMillis()
        );
        showCloveNotification(message);
    }


    // =========================================================
    // SCAN FOR CLOVE
    // =========================================================

    private void scanForClove() {

        if (bluetoothAdapter == null) {

            return;
        }


        if (!bluetoothAdapter.isEnabled()) {

            txtDetectionStatus.setText(
                    "Please turn Bluetooth ON"
            );
            txtConnectionStatus.setText(
                    "Please turn Bluetooth ON"
            );

            return;
        }


        // =====================================================
        // CHECK PERMISSIONS
        // =====================================================

        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.BLUETOOTH_SCAN
        ) != PackageManager.PERMISSION_GRANTED
                ||
                ActivityCompat.checkSelfPermission(
                        this,
                        Manifest.permission.BLUETOOTH_CONNECT
                ) != PackageManager.PERMISSION_GRANTED) {


            ActivityCompat.requestPermissions(
                    this,

                    new String[]{
                            Manifest.permission.BLUETOOTH_SCAN,
                            Manifest.permission.BLUETOOTH_CONNECT
                    },

                    REQUEST_BLUETOOTH_PERMISSIONS
            );

            return;
        }


        // =====================================================
        // GET SCANNER
        // =====================================================

        bluetoothScanner =
                bluetoothAdapter.getBluetoothLeScanner();


        if (bluetoothScanner == null) {

            txtDetectionStatus.setText(
                    "BLE scanner unavailable"
            );
            txtConnectionStatus.setText(
                    "BLE scanner unavailable"
            );

            return;
        }


        cloveDevice = null;


        txtDetectionStatus.setText(
                "Scanning..."
        );
        txtConnectionStatus.setText(
                "Scanning..."
        );


        // =====================================================
        // START SCANNING
        // =====================================================

        bluetoothScanner.startScan(
                scanCallback
        );


        // =====================================================
        // STOP AFTER 10 SECONDS
        // =====================================================

        handler.postDelayed(() -> {

            if (bluetoothScanner == null) {

                return;
            }


            if (ActivityCompat.checkSelfPermission(
                    MainActivity.this,
                    Manifest.permission.BLUETOOTH_SCAN
            ) != PackageManager.PERMISSION_GRANTED) {

                return;
            }


            bluetoothScanner.stopScan(
                    scanCallback
            );


            if (cloveDevice == null) {

                txtDetectionStatus.setText(
                        "CLOVE not found"
                );
                txtConnectionStatus.setText(
                        "CLOVE not found"
                );
                btnConnection.setText("Try Again");
            }

        }, 10000);
    }


    // =========================================================
    // SCAN CALLBACK
    // =========================================================

    private final ScanCallback scanCallback =
            new ScanCallback() {

                @Override
                public void onScanResult(
                        int callbackType,
                        ScanResult result
                ) {

                    if (ActivityCompat.checkSelfPermission(
                            MainActivity.this,
                            Manifest.permission.BLUETOOTH_CONNECT
                    ) != PackageManager.PERMISSION_GRANTED) {

                        return;
                    }


                    BluetoothDevice device =
                            result.getDevice();


                    String deviceName =
                            device.getName();


                    if (deviceName == null) {

                        deviceName =
                                "Unknown Device";
                    }


                    // =================================================
                    // LOOK FOR ESP32
                    // =================================================

                    if ("CLOVE_TEST".equals(
                            deviceName
                    )) {

                        cloveDevice = device;


                        if (bluetoothScanner != null) {

                            bluetoothScanner.stopScan(
                                    scanCallback
                            );
                        }


                        runOnUiThread(() -> {

                            txtDetectionStatus.setText(
                                    "CLOVE_TEST found!"
                            );
                            txtConnectionStatus.setText(
                                    "CLOVE_TEST found!"
                            );
                            btnConnection.setText("Connect");

                        });
                    }
                }


                @Override
                public void onScanFailed(
                        int errorCode
                ) {

                    runOnUiThread(() -> {

                        txtDetectionStatus.setText(
                                "Scan failed: " +
                                        errorCode
                        );
                        txtConnectionStatus.setText(
                                "Scan failed: " +
                                        errorCode
                        );

                    });
                }
            };


    // =========================================================
    // CONNECT TO CLOVE
    // =========================================================

    private void connectToClove() {

        if (cloveDevice == null) {

            txtDetectionStatus.setText(
                    "Scan for CLOVE first!"
            );
            txtConnectionStatus.setText(
                    "Scan for CLOVE first!"
            );

            return;
        }


        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.BLUETOOTH_CONNECT
        ) != PackageManager.PERMISSION_GRANTED) {

            return;
        }


        txtDetectionStatus.setText(
                "Connecting..."
        );
        txtConnectionStatus.setText(
                "Connecting..."
        );


        bluetoothGatt =
                cloveDevice.connectGatt(
                        this,
                        false,
                        gattCallback
                );
    }


    // =========================================================
    // DISCONNECT
    // =========================================================

    private void disconnectFromClove() {

        if (bluetoothGatt == null) {

            txtDetectionStatus.setText(
                    "Already disconnected"
            );
            txtConnectionStatus.setText(
                    "Already disconnected"
            );

            return;
        }


        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.BLUETOOTH_CONNECT
        ) != PackageManager.PERMISSION_GRANTED) {

            return;
        }


        txtDetectionStatus.setText(
                "Disconnecting..."
        );
        txtConnectionStatus.setText(
                "Disconnecting..."
        );


        bluetoothGatt.disconnect();
    }


    // =========================================================
    // GATT CALLBACK
    // =========================================================

    private final BluetoothGattCallback gattCallback =
            new BluetoothGattCallback() {


                // =====================================================
                // CONNECTION STATE
                // =====================================================

                @Override
                public void onConnectionStateChange(
                        BluetoothGatt gatt,
                        int status,
                        int newState
                ) {


                    if (newState ==
                            BluetoothProfile.STATE_CONNECTED) {


                        runOnUiThread(() -> {

                            txtDetectionStatus.setText(
                                    "Connected!"
                            );
                            txtConnectionStatus.setText(
                                    "Connected!"
                            );


                        });


                        // Discover services

                        if (ActivityCompat.checkSelfPermission(
                                MainActivity.this,
                                Manifest.permission.BLUETOOTH_CONNECT
                        ) == PackageManager.PERMISSION_GRANTED) {


                            gatt.discoverServices();
                        }

                    }


                    else if (
                            newState ==
                                    BluetoothProfile.STATE_DISCONNECTED
                    ) {


                        runOnUiThread(() -> {

                            txtDetectionStatus.setText(
                                    "Disconnected"
                            );
                            txtConnectionStatus.setText(
                                    "Disconnected"
                            );

                        });


                        gatt.close();

                        bluetoothGatt = null;
                    }
                }


                // =====================================================
                // SERVICES DISCOVERED
                // =====================================================

                @Override
                public void onServicesDiscovered(
                        BluetoothGatt gatt,
                        int status
                ) {


                    if (status !=
                            BluetoothGatt.GATT_SUCCESS) {


                        runOnUiThread(() -> {
                            txtDetectionStatus.setText(
                                    "Service discovery failed"
                            );
                            txtConnectionStatus.setText(
                                    "Service discovery failed"
                            );

                        });

                        return;
                    }


                    // =================================================
                    // GET SERVICE
                    // =================================================

                    android.bluetooth.BluetoothGattService service =
                            gatt.getService(
                                    SERVICE_UUID
                            );


                    if (service == null) {

                        runOnUiThread(() ->{
                            txtDetectionStatus.setText(
                                    "CLOVE service not found"
                            );
                            txtConnectionStatus.setText(
                                    "CLOVE service not found"
                            );
                                }

                        );

                        return;
                    }


                    // =================================================
                    // GET CHARACTERISTIC
                    // =================================================

                    BluetoothGattCharacteristic characteristic =
                            service.getCharacteristic(
                                    CHARACTERISTIC_UUID
                            );


                    if (characteristic == null) {

                        runOnUiThread(() -> {
                            txtDetectionStatus.setText(
                                    "CLOVE characteristic not found"
                            );
                            txtConnectionStatus.setText(
                                    "CLOVE characteristic not found"
                            );

                        });

                        return;
                    }


                    // =================================================
                    // ENABLE NOTIFICATIONS
                    // =================================================

                    enableNotifications(
                            gatt,
                            characteristic
                    );
                }


                // =====================================================
                // RECEIVE BLE MESSAGE
                // =====================================================

                @Override
                public void onCharacteristicChanged(
                        BluetoothGatt gatt,
                        BluetoothGattCharacteristic characteristic
                ) {


                    if (!CHARACTERISTIC_UUID.equals(
                            characteristic.getUuid()
                    )) {

                        return;
                    }


                    byte[] data =
                            characteristic.getValue();


                    String message =
                            new String(
                                    data,
                                    StandardCharsets.UTF_8
                            );


                    // =================================================
                    // SEND BLE MESSAGE TO CLOVE MESSAGE SYSTEM
                    // =================================================

                    runOnUiThread(() -> {

                        receiveMessage(
                                message.trim()
                        );

                    });
                }
            };


    // =========================================================
    // ENABLE NOTIFICATIONS
    // =========================================================

    private void enableNotifications(
            BluetoothGatt gatt,
            BluetoothGattCharacteristic characteristic
    ) {


        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.BLUETOOTH_CONNECT
        ) != PackageManager.PERMISSION_GRANTED) {

            return;
        }


        // Tell Android to listen for notifications

        gatt.setCharacteristicNotification(
                characteristic,
                true
        );


        BluetoothGattDescriptor descriptor =
                characteristic.getDescriptor(
                        CLIENT_CHARACTERISTIC_CONFIG_UUID
                );


        if (descriptor != null) {

            descriptor.setValue(
                    BluetoothGattDescriptor
                            .ENABLE_NOTIFICATION_VALUE
            );


            gatt.writeDescriptor(
                    descriptor
            );
        }


        runOnUiThread(() -> {
            txtDetectionStatus.setText(
                    "CLOVE ready!"
            );
            txtConnectionStatus.setText(
                    "CLOVE ready!"
            );

        });
    }


    // =========================================================
    // PERMISSION RESULT
    // =========================================================

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults
    ) {


        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults
        );


        if (requestCode ==
                REQUEST_BLUETOOTH_PERMISSIONS) {


            if (grantResults.length > 0) {


                boolean allGranted = true;


                for (int result :
                        grantResults) {


                    if (result !=
                            PackageManager.PERMISSION_GRANTED) {

                        allGranted = false;

                        break;
                    }
                }


                if (allGranted) {

                    scanForClove();

                } else {

                    txtDetectionStatus.setText(
                            "Bluetooth permission denied"
                    );
                    txtConnectionStatus.setText(
                            "Bluetooth permission denied"
                    );
                }
            }
        }
    }


    // =========================================================
    // CLEAN UP BLE WHEN APP CLOSES
    // =========================================================

    @Override
    protected void onDestroy() {

        super.onDestroy();


        if (bluetoothGatt != null) {

            if (ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.BLUETOOTH_CONNECT
            ) == PackageManager.PERMISSION_GRANTED) {

                bluetoothGatt.close();
            }

            bluetoothGatt = null;
        }
    }

    // =========================================================
    // Notification
    // =========================================================
    private void showCloveNotification(String message) {

        NotificationManager notificationManager =
                (NotificationManager)
                        getSystemService(
                                Context.NOTIFICATION_SERVICE
                        );

        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(
                        this,
                        "CLOVE_MESSAGES"
                )
                        .setSmallIcon(android.R.drawable.ic_dialog_info)
                        .setContentTitle("CLOVE")
                        .setContentText(message)
                        .setPriority(
                                NotificationCompat.PRIORITY_HIGH
                        )
                        .setAutoCancel(true);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {

            if (ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED) {

                return;
            }
        }

        notificationManager.notify(
                (int) System.currentTimeMillis(),
                builder.build()
        );
    }
}
