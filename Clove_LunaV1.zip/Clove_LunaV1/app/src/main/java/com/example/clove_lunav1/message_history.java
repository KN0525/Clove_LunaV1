package com.example.clove_lunav1;

import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class message_history extends AppCompatActivity {

    // Test history message
    LinearLayout historyContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);

        setContentView(R.layout.activity_message_history);

        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main),
                (v, insets) -> {

                    Insets systemBars =
                            insets.getInsets(
                                    WindowInsetsCompat.Type.systemBars()
                            );

                    v.setPadding(
                            systemBars.left,
                            systemBars.top,
                            systemBars.right,
                            systemBars.bottom
                    );

                    return insets;
                }
        );

        historyContainer = findViewById(R.id.historyContainer);

        displayHistory();
    }

    private void displayHistory() {

        historyContainer.removeAllViews();

        for (String history : MainActivity.messageHistory) {

            // Separate message and timestamp
            String[] parts = history.split("\\|");

            String message = parts[0];
            long timestamp = Long.parseLong(parts[1]);

            // Create history card
            android.view.View card = getLayoutInflater().inflate(
                    R.layout.item_message_history,
                    historyContainer,
                    false
            );

            TextView txtMessage =
                    card.findViewById(R.id.txtHistoryMessage);

            TextView txtTime =
                    card.findViewById(R.id.txtHistoryTime);

            // Display message
            txtMessage.setText(message);

            // Display actual time
            SimpleDateFormat sdf =
                    new SimpleDateFormat("hh:mm a", Locale.getDefault());

            txtTime.setText(sdf.format(new Date(timestamp)));

            // Add card
            historyContainer.addView(card);
        }
    }
}