
package com.example.clove_lunav1;

import android.os.Bundle;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Arrays;

public class Customize extends AppCompatActivity {

    private TextView[] messageViews;
    private Button[] editButtons;

    private android.content.SharedPreferences preferences;

    private final String[] defaultMessages = {
            "Yes",
            "I need water",
            "I need help",
            "Not set",
            "Not set",
            "Not set",
            "Not set",
            "Not set",
            "Not set",
            "Not set",
            "Not set",
            "Not set"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_customize);

        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main),
                (v, insets) -> {
                    Insets systemBars = insets.getInsets(
                            WindowInsetsCompat.Type.systemBars()
                    );

                    v.setPadding(
                            systemBars.left,
                            systemBars.top,
                            systemBars.right,
                            systemBars.bottom
                    );

                    return insets;
                }
        );

        preferences = getSharedPreferences(
                "clove_custom_messages",
                MODE_PRIVATE
        );

        messageViews = new TextView[]{
                findViewById(R.id.messageText1),
                findViewById(R.id.messageText2),
                findViewById(R.id.messageText3),
                findViewById(R.id.messageText4),
                findViewById(R.id.messageText5),
                findViewById(R.id.messageText6),
                findViewById(R.id.messageText7),
                findViewById(R.id.messageText8),
                findViewById(R.id.messageText9),
                findViewById(R.id.messageText10),
                findViewById(R.id.messageText11),
                findViewById(R.id.messageText12)
        };

        editButtons = new Button[]{
                findViewById(R.id.btnEditMessage1),
                findViewById(R.id.btnEditMessage2),
                findViewById(R.id.btnEditMessage3),
                findViewById(R.id.btnEditMessage4),
                findViewById(R.id.btnEditMessage5),
                findViewById(R.id.btnEditMessage6),
                findViewById(R.id.btnEditMessage7),
                findViewById(R.id.btnEditMessage8),
                findViewById(R.id.btnEditMessage9),
                findViewById(R.id.btnEditMessage10),
                findViewById(R.id.btnEditMessage11),
                findViewById(R.id.btnEditMessage12)
        };

        loadMessages();

        for (int i = 0; i < editButtons.length; i++) {
            final int position = i;

            editButtons[i].setOnClickListener(
                    v -> showEditDialog(position)
            );
        }
    }

    private void loadMessages() {
        for (int i = 0; i < messageViews.length; i++) {
            String savedMessage = preferences.getString(
                    "message_" + (i + 1),
                    defaultMessages[i]
            );

            messageViews[i].setText(savedMessage);
        }
    }

    private void showEditDialog(int position) {

        EditText input = new EditText(this);

        input.setHint("Enter your message");
        input.setTextSize(16);
        input.setTextColor(Color.BLACK);
        input.setHintTextColor(Color.GRAY);
        input.setMinLines(2);
        input.setMaxLines(4);
        input.setGravity(
                android.view.Gravity.TOP
                        | android.view.Gravity.START
        );
        input.setPadding(32, 24, 32, 24);

        String currentMessage =
                messageViews[position].getText().toString();

        if (!currentMessage.equals("Not set")) {
            input.setText(currentMessage);
            input.setSelection(input.getText().length());
        }

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Edit Gesture " + (position + 1))
                .setMessage("Enter the message for this gesture.")
                .setView(input)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", (d, which) -> d.dismiss())
                .create();

        dialog.setOnShowListener(d -> {
            Window window = dialog.getWindow();

            if (dialog.getWindow() != null) {
                dialog.getWindow().setSoftInputMode(
                        android.view.WindowManager.LayoutParams
                                .SOFT_INPUT_STATE_ALWAYS_HIDDEN
                );
            }

            Button saveButton = dialog.getButton(
                    AlertDialog.BUTTON_POSITIVE
            );

            saveButton.setOnClickListener(v -> {

                String newMessage = input.getText()
                        .toString()
                        .trim();

                if (newMessage.isEmpty()) {
                    input.setError("Please enter a message");
                    return;
                }

                // Save only the selected gesture.
                preferences.edit()
                        .putString(
                                "message_" + (position + 1),
                                newMessage
                        )
                        .apply();

                // Update only the selected message on screen.
                messageViews[position].setText(newMessage);

                Toast.makeText(
                        Customize.this,
                        "Gesture " + (position + 1)
                                + " message saved",
                        Toast.LENGTH_SHORT
                ).show();

                dialog.dismiss();
            });
        });

        dialog.show();
    }
}
